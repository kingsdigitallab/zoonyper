# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['zoonyper']

package_data = \
{'': ['*']}

install_requires = \
['pandas==1.4.1', 'requests==2.25.1']

setup_kwargs = {
    'name': 'zoonyper',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Kalle Westerling',
    'author_email': 'kalle.westerling@bl.uk',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
