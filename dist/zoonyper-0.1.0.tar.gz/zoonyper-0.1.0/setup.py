# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['zoonyper']

package_data = \
{'': ['*'],
 'zoonyper': ['docs/doctrees/*',
              'docs/html/*',
              'docs/html/_sources/*',
              'docs/html/_static/*',
              'docs/html/_static/scripts/*',
              'docs/html/_static/styles/*']}

install_requires = \
['furo>=2022.4.7,<2023.0.0',
 'ipykernel>=6.13.0,<7.0.0',
 'pandas==1.4.1',
 'requests==2.25.1',
 'tqdm>=4.64.0,<5.0.0']

setup_kwargs = {
    'name': 'zoonyper',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Kalle Westerling',
    'author_email': 'kalle.westerling@bl.uk',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
